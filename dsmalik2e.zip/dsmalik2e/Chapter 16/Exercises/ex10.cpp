#include <iostream>
using namespace std;

int gcd(int x, int y);

int main()
{
    int firstNum, secondNum;
    
    cout << "This program determines the GCD of two integer.\n";
    cout << "Please enter the first number: ";
    cin >> firstNum;
    cout << "Please enter the second number: ";
    cin >> secondNum;
     
    cout << "The GCD of numbers is: " << gcd(firstNum, secondNum) << endl;

    return 0;
}

int gcd(int x, int y)
{
    if (y == 0)
        return x;
    else
        return gcd(y, x % y);
}
