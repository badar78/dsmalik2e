#include <iostream>
using namespace std;

void reverseDigits(int num);

int main()
{
    int number;
    
    cout << "Enter a positive integer: ";
    cin >> number;
    cout << "The number with digits reversed is ";
    reverseDigits(number);
    cout << endl;

    return 0;
}

void reverseDigits(int num)
{
   if (num > 0)
   {
       cout << num % 10; 
       reverseDigits(num / 10);                
   }
}
