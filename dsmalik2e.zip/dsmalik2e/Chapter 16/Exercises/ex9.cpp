#include <iostream>
using namespace std;

int power(int x, int y);

int main()
{
    int firstNum, secondNum;
   
    cout << "This program determines the x raised to power y of two integer.\n";
    cout << "Please enter the value of x(integer other than 0): ";
    cin >> firstNum;
    while (firstNum == 0)
    {
        cout << "Value of x can't be zero. Enter again: ";
        cin >> firstNum;
    }
    cout << "Please enter the value of y (an integer): ";
    cin >> secondNum;
    
    if (secondNum < 0)
        cout << "The x raised to power y is: 1 / " << power(firstNum, secondNum) << endl;
    else
        cout << "The x raised to power y is: " << power(firstNum, secondNum) << endl;

    return 0;
}

int power(int x, int y)
{
    if (y == 0)
        return 1;
    else if (y == 1)
        return x;
    else if (y > 1)
        return x * power(x, y - 1);
    else
        return power(x,-y);
}
