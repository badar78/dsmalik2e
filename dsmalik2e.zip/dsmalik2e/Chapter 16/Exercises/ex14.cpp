#include <iostream>
using namespace std;

void decToBase(int num, int base);

int main()
{
    int decimalNum;
    int base;

    cout << "Enter number in decimal: ";
    cin >> decimalNum;
    cout << "Enter the base to convert to (between 2 and 36): ";
    cin >> base;
    cout << "Decimal " << decimalNum << " = ";
    decToBase(decimalNum, base);
    cout << " in base " << base << endl;

    return 0;
}

void decToBase(int num, int base)
{
   if (num > 0)
   {
        decToBase(num / base, base);
        if (num % base < 10)
            cout << num % base;
        else
            cout << static_cast<char>(num % base + 55);  //As ASCII value for A is 65
   }
}
