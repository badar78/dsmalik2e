#include <iostream>
using namespace std;

int combinations(int n, int r);

int main()
{
    int total, selection;
    
    cout << "This program determines the number of ways r differnet things\n "
        << "can be chosen from a set of n items.\n";
    cout << "Please enter the value of n: ";
    cin >> total;
    cout << "Please enter the value of r: ";
    cin >> selection;
     
    cout << "The numbers of ways are: " << combinations(total, selection) << endl;

    return 0;
}

int combinations(int n, int r)
{
    if (r == 0)
        return 1;
    else if (n == r)
        return 1;
    else
        return combinations(n - 1, r - 1) + combinations(n - 1, r);
}
