#include <iostream>
using namespace std;

int multiply(int m, int n);

int main()
{
    int firstNumber, secondNumber;
    int data[10] = {2, 5, 4, 16, 38, 35, 12, 89, 14, 20};

    cout << "This program multiply to postive integers. It uses recursive algorithm\n"
        << "with repeated addition.\n";
    cout << "Please enter the first number(a positive integer): ";
    cin >> firstNumber;
    cout << "Please enter the second number(a positive integer): ";
    cin >> secondNumber;
    
    cout << "The product of integers is: " << multiply(firstNumber, secondNumber)
        << endl;
    
    return 0;
}

int multiply(int m, int n)
{
    if ( m == 0 || n == 0)
        return 0;
    else if (n == 1)
        return m;
    else
        return m + multiply(m, n - 1);
}