#include <iostream>
using namespace std;

void reverseArray(int data[], int low, int high);

int main()
{
    int indexLow, indexHigh;
    int data[10] = {2, 5, 4, 16, 38, 35, 12, 89, 14, 20};

    cout << "This program reverses the element of an array between two indices.\n";
    cout << "Please enter the lower index (0-9): ";
    cin >> indexLow;
    cout << "Please enter the higher index: ";
    cin >> indexHigh;
    
    reverseArray(data, indexLow, indexHigh);
    cout << "After the reversing between indices the array is.\n";
    for (int i = 0; i < 10; i++)
        cout << data[i] << " ";
    cout << endl;

    return 0;
}

void reverseArray(int data[], int low, int high)
{
    if (low < high)
    {
        swap(data[low],data[high]);
        reverseArray(data, low + 1, high - 1);
    }
}
