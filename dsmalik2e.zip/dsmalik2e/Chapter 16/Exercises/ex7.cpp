#include <iostream>
#include <string>
using namespace std;

string reverseString(string s);

int main()
{
    string stg;
    
    cout << "Please enter a string: ";
    getline(cin, stg);
    cout << "The reversed string is : " << reverseString(stg) << endl;
   
    return 0;
}
string reverseString(string s)
{
    int length;

    length = s.length();
    if (length == 1)
        return s;
    else
        return reverseString(s.substr(1, length)) + s[0];
}

