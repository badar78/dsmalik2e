#include <iostream>
using namespace std;

void printStars(int n);

int main()
{
    int number;
   
    cout << "Please enter a positve integer: ";
    cin >> number;
    
    printStars(number);

    return 0;
}

void printStars(int n)
{
    for (int i = 0; i < n; i++)
        cout << "*";
    cout << endl;
    if(n > 1)
        printStars(n - 1);
    for (int i = 0; i < n; i++)
        cout << "*";
    cout << endl;
}

