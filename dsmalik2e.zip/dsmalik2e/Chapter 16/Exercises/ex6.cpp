#include <iostream>
#include <string>
using namespace std;

bool isPalindrome(string s, int lowerIndex, int higherIndex);

int main()
{
    string stg;
    int higher;
    cout << "Please enter a string: ";
    cin >> stg;
    higher = stg.length() - 1;
    if (isPalindrome(stg, 0, higher))
        cout << "The string is a palindrome.\n";
    else
        cout << "The string is not a palindrome.\n";

    return 0;
}

bool isPalindrome(string s, int lowerIndex, int higherIndex)
{
    if (lowerIndex <= higherIndex)
        if (s[lowerIndex] != s[higherIndex])
            return false;
        else
        {
            isPalindrome(s, lowerIndex + 1, higherIndex -1);
            return true;
        }
}

