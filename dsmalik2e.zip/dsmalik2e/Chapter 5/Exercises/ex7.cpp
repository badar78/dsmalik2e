#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int number, limit;
    bool isPrime = true;
    
    cout << "Enter an integer: ";
    cin >> number;

    limit = static_cast<int>(pow(abs(number), 0.5));
    
    if (number == 2 || number == -2)
        isPrime = true;
    else if (number % 2 == 0)
        isPrime = false;
    else
        for (int i = 3; i <= limit; i += 2)
        {
            if (number % i == 0)
            {
                isPrime = false;
                break;
            }
        }

    if (number == 1 || number == -1)
        cout << "The number is neither prime nor composite." << endl;
    else if (isPrime)
        cout << "The number is prime." << endl;
    else
        cout << "The number is composite." << endl;

    return 0;
}