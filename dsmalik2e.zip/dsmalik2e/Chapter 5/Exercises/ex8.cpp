#include <iostream>

using namespace std;

int main()
{
    int firstNum, secondNum,  number;
    int sumEvens = 0, sumSquaresOfOdds = 0;
    char letter = 'A';

    cout << "Enter the first number: ";
    cin >> firstNum;
    cout << "Enter the second number(greater than the first): ";
    cin >> secondNum;

    if (firstNum >= secondNum)
    {
        cout << "The second number should be greater.\nProgram Terminating.\n";
        return 1;
    }

    //Parts b,c and e.Outputting all odd numbers and calculating required sums.
    cout << "All odd numbers between " << firstNum << " and " << secondNum
        << " are as follows: " << endl;
    number = firstNum;
    while(number <= secondNum)
    {
        switch(number % 2)
        {
        case 1: case -1:
            cout << number << " ";
            sumSquaresOfOdds += (number * number);
            break;
        case 0:
            sumEvens += number;
            break;
        }
        number++;
    }
    
    cout << "\n\nThe sum of all even numbers bewtween " << firstNum << " and "
        << secondNum << " = " << sumEvens << endl;
    cout << "The sum of squares of all odd numbers bewtween " << firstNum 
        << " and " << secondNum << " = " << sumSquaresOfOdds << endl << endl;

    //Outputting the squares using for loop.
    cout << "The squares of numbers between 1 and 10.\n\n";
    for (number=1; number <= 10; number++)
        cout << "The square of " << number << " = " << number * number << endl;

    //Outputting using do...while loop.
    cout << "\nAll upper case letters are as follows.\n";
    do
    {
        cout << letter << " ";
        letter = letter + 1;
    }
    while (letter <= 'Z');
   
    cout << endl;
    return 0;
}