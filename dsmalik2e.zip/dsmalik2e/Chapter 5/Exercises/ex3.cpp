#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main()
{
    int number, reverse = 0;
    int pwr, divider, multiplier = 1;
    
    cout << "Enter a positive integer : ";
    cin >> number;

    //Determine the highest power of 10 dividing the number.
    for ( pwr = 0; number / static_cast<int>(pow(10.0, pwr)) > 10; pwr++);
    
    divider = static_cast<int>(pow(10.0,pwr));
    
    while (divider >= 1)
    {
        reverse += (number / divider) * multiplier;
        number = number % divider;
        multiplier *= 10;
        divider /= 10;
    }

    cout << setfill('0') << "The number with digits reversed is: " 
        << setw(pwr + 1)<< reverse << endl;

    return 0;
}