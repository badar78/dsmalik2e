#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int number, pwr, factor;
    int sum = 0, digit;

    cout << "Enter an integer : ";
    cin >> number;

    if (number < 0)
        number = -number;

    //Determine the highest power of 10 dividing the number
    for ( pwr = 0; number / static_cast<int>(pow(10.0, pwr)) > 10; pwr++);

    factor = static_cast<int>(pow(10.0,pwr));
    cout << "The individual digits are: ";
    
    while (factor >= 1)
    {
        digit = number / factor;
        number = number % factor;
        sum = sum + digit;
        cout << digit << " ";
        factor = factor /10;
    }
    cout << endl;

    cout << "The sum of digits = " << sum << endl;

    return 0;
}