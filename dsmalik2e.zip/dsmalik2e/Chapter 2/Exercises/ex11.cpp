#include <iostream>

using namespace std;

int main()
{
    int time;
    int hours;
    int mins;
    int secs;

    cout << "Input time in seconds: ";
    cin >> time;

    hours = time / 3600;
    time = time % 3600;
    mins = time / 60;
    secs = time % 60;
    cout << "Time is " << hours << ":" << mins << ":" << secs << endl;
    
    return 0;
}