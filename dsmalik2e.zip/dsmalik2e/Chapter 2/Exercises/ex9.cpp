#include <iostream>

using namespace std;

int main()
{
    double num1, num2, num3, num4, num5;
    int inum1, inum2,inum3, inum4,inum5;
    int sum, avg;

    cout << "Input five decimal numbers: ";
    cin >> num1 >> num2 >> num3 >> num4 >> num5;

    inum1 = static_cast<int>(num1 + 0.5);
    inum2 = static_cast<int>(num2 + 0.5);
    inum3 = static_cast<int>(num3 + 0.5);
    inum4 = static_cast<int>(num4 + 0.5);
    inum5 = static_cast<int>(num5 + 0.5);
    sum = inum1 + inum2 + inum3 + inum4 + inum5;
    avg = static_cast<int>(sum/5.0 + 0.5);
    cout << "The numbers to the nearest integer are: " 
        << inum1 << " " << inum2 << " " << inum3
        << " " << inum4 << " " << inum5 << endl << endl;
    cout << "The sum of integers is : " << sum << endl;
    cout << "The average of integers is : " << avg << endl;

    return 0;
}