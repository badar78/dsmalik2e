#include <iostream>

using namespace std;

const double cmPerInch = 2.54;
int main()
{
    int cm;
    int inch;
    int yards;
    int feet;
   

    cout << "Input the length in cm (integer) : ";
    cin >> cm;
    inch = static_cast <int> (cm / cmPerInch + 0.5);

    yards = inch / 36;
    inch %= 36;
    feet = inch / 12;
    inch %= 12;
    cout << "Length is " << yards << " yard(s), " << feet << " feet(foot) and "
         << inch << " inch(es)" << endl;
    
    return 0;
}