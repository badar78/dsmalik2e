#include <iostream>

using namespace std;

int main()
{
    int number;
    int digit;

    cout << "Input a four digit number: ";
    cin >> number;

    digit = number / 1000;
    cout << digit << endl;
    number = number % 1000;
    digit = number / 100;
    cout << digit << endl;
    number = number % 100;
    digit = number / 10;
    cout << digit << endl;
    number = number % 10;
    cout << number << endl;

    return 0;
}