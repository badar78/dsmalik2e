//This program tests the various operations of a linked stack

#include <iostream>
#include "derivedLinkedStack.h"

using namespace std;

int main()
{
	cout << "Create your own program. " << endl; 

	return 0;
}
