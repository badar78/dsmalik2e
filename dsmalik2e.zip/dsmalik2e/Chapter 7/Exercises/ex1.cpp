#include <iostream>
#include <iomanip>

using namespace std;

void initialize(int& num1, int& num2, char& ch);
void getHoursRate(double& hoursWorked, double& ratePerHour);
double payCheck(double hoursWorked, double ratePerHour);
void printCheck(double hoursWorked, double ratePerHour, double amountDue);
void funcOne(int& num1, int& num2);
void nextChar(char& ch);

int main ()
{
    int x, y;
    char z;
    double rate, hours;
    double amount;

    initialize(x, y, z);
    cout << "After function initialize executes the value of x = " << x 
        << " , y = " << y << " and z = " << z << endl << endl;
    
    getHoursRate(hours, rate);
    amount = payCheck(hours, rate);
    printCheck(hours, rate, amount);

    cout << "Enter new value for x(integer): ";
    cin >> x;
    cout << "Enter new value for y(integer): ";
    cin >> y;
    funcOne(x, y);
    cout << "After function funcOne executes the value of x = " << x 
        << " , y = " << y << endl << endl;

    cout << "Enter new value for z(charr): ";
    cin >> z;
    nextChar(z);
    cout << "After function nextChar executes the new value of z is: "
        << z << endl;
    return 0;
}

void initialize(int& num1, int& num2, char& ch)
{
    num1 = 0;
    num2 = 0;
    ch = ' ';
}

void getHoursRate(double& hoursWorked, double& ratePerHour)
{
    cout << "Enter the hours worked: ";
    cin >> hoursWorked;
    cout << "Enter the rate per hour: ";
    cin >> ratePerHour;
}

double payCheck(double hoursWorked, double ratePerHour)
{
    double amountDue;
    if (hoursWorked <= 40)
        amountDue = ratePerHour * hoursWorked;
    else
        amountDue = ratePerHour * 40 + 1.5 * ratePerHour * (hoursWorked - 40);
    return amountDue;
}

void printCheck(double hoursWorked, double ratePerHour, double amountDue)
{
    cout << fixed << showpoint << setprecision(2);
    cout << "\nThe hours worked are: " << hoursWorked << endl;
    cout << "The rate per hours is: " << ratePerHour << endl;
    cout << "The amount due is: " << amountDue << endl;
}

void funcOne(int& num1, int& num2)
{
    int number;
    cout << "Enter an integer: ";
    cin >> number;
    num1 = 2 * num1 + num2 - number;
}

void nextChar(char& ch)
{
    ch++;
}