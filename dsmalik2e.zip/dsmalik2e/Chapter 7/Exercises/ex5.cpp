#include <iostream>
using namespace std;

bool isLeapYear(int year);
int dayNumber(int month, int day, int year);
void getData(int& month, int& day, int& year);

int main ()
{
    int yr, mon, day;

    getData(mon, day, yr);
    cout << "The day number is :" << dayNumber(mon, day, yr) << endl; 

    return 0;
}

void getData(int& month, int& day, int& year)
{
    cout << "Enter the date in form of month-day-year(i.e. 1-3-2005): ";
    cin >> month;
    cin.ignore(2,'-');
    cin >> day;
    cin.ignore(2,'-');
    cin >> year;
}
bool isLeapYear(int year)
{
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        return true;
    return false;
}

int dayNumber(int month, int day, int year)
{
    int Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov;
    int number;

    Jan = Mar = May = Jul = Aug = Oct = 31;
    Apr = Jun = Sep = Nov = 30;
    Feb =  28;
    if (isLeapYear(year))
        Feb = 29;
    
    switch(month)
    {
    case 1:
        number = day;
        break;
    case 2:
        number = Jan + day;
        break;
    case 3:
        number = Jan + Feb + day;
        break;
    case 4:
        number = Jan + Feb + Mar + day;
        break;
    case 5:
        number = Jan + Feb + Mar + Apr + day;
        break;
    case 6:
        number = Jan + Feb + Mar + Apr + May + day;
        break;
    case 7:
        number = Jan + Feb + Mar + Apr + May + Jun + day;
        break;
    case 8:
        number = Jan + Feb + Mar + Apr + May + Jun + Jul + day;
        break;
    case 9:
        number = Jan + Feb + Mar + Apr + May + Jun + Jul + Aug + day;
        break;
    case 10:
        number = Jan + Feb + Mar + Apr + May + Jun + Jul + Aug + Sep + day;
        break;
    case 11:
        number = Jan + Feb + Mar + Apr + May + Jun + Jul + Aug + Sep + Oct + day;
        break;
    case 12:
        number = Jan + Feb + Mar + Apr + May + Jun + Jul + Aug + Sep + Oct + Nov + day;
        break;
    default:
        cout << "Invalid Month Entered. Try Again.\n";
        getData(month, day, year);
        return dayNumber(month, day, year);
    }
    return number;
}



