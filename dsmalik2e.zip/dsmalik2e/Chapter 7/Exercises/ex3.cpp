//Program: Classify Numbers
// This program counts the number of zeros, odd, and even numbers 
// Calcultes their sum, average. redas input from file and write output
// to a file.
#include <iostream>
#include <fstream>
using namespace std;

//function prototypes
void initialize(int& zeroCount, int& oddCount, int& evenCount);
bool getNumber(ifstream& input, ofstream& output, int& num);
void classifyNumber(int num, int& zeroCount, int& oddCount, 
			  int& evenCount);
void printResults(ofstream& output, int zeroCount, int oddCount, int evenCount,
                  int totalSum, int average);

int main ()
{
		//variable declrearation
	int counter = 0; //to count the numbers 
	int number;     //variable to store the new number 
	int zeros;      //variable to store the number of zeros 
	int odds;       //variable to store the number of odd integers 
	int evens;      //variable to store the number of even integers
    int sum = 0;
    int avg = 0;

    ifstream inFile;
    ofstream outFile;

    inFile.open("C:\\temp\\ex7.3data.txt");
    if (!inFile)        
    {
        cout << "No input file found.\nProgram terminating.\n";
        return 1;
    }
    outFile.open("C:\\temp\\ex7.3.out");
    cout << "Processing Input File.\n";
    outFile << "The numbers read from input file are as follows.\n\n";
	initialize(zeros, odds, evens);						

	while(getNumber(inFile, outFile, number))			
	{
		counter++;
        sum += number;
		classifyNumber(number, zeros, odds, evens);
    }

	if (counter != 0)
        avg = sum / counter;

	printResults(outFile, zeros, odds, evens, sum, avg);					
    
    inFile.close();
    outFile.close();
	return 0;
}

void initialize(int& zeroCount, int& oddCount, int& evenCount)
{
	zeroCount = 0;
	oddCount = 0;
	evenCount = 0;
}

bool getNumber(ifstream& input, ofstream& output, int& num)
{   
    static int total = 0;
	input >> num;
    if (input)
    {   
        total++;
        output << num << " ";
        if (total % 10 == 0)
            output << endl;
        return true;
    }

    return false;
}

void classifyNumber(int num, int& zeroCount, int& oddCount,
			        int& evenCount)
{
   switch (num % 2)
   {
   case 0: evenCount++;  
	       if (num == 0)			 
	 			zeroCount++;  
		   break;
   case 1: 
   case -1: oddCount++;	
   } //end switch
}

void printResults(ofstream& output, int zeroCount, int oddCount, int evenCount,
                  int totalSum, int average)
{ 
    output << "\n\nThere are " << evenCount << " evens, "
	     << "which also includes " << zeroCount << " zeros"
         << endl;	

    output << "The number of odd numbers is: " << oddCount
         << endl;
    output << "The sum of all numbers is: " << totalSum << endl;
    output << "The average of all numbers is: " << average << endl;
}
