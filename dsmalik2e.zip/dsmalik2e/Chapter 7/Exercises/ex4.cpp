#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//function prototypes
void openFiles(ifstream& input, ofstream& output);
void initialize(int& female, int& male, double& sumFemale, double& sumMale);
void sumGrades(ifstream& input, int& female, int& male, double& sumFemale,
               double& sumMale);
double averageGrade(double sum, int number);
void printResults(ofstream& output, double femaleAvg, double maleAvg);
void closeFiles(ifstream& input, ofstream& output);

int main ()
{
	int countFemale, countMale;  //to count male and female students. 
	double sumFemaleGPA, sumMaleGPA;
    double avgFemale, avgMale;

    ifstream inFile;
    ofstream outFile;

    openFiles(inFile, outFile);
    if (!inFile)        
    {
        cout << "No input file found.\nProgram terminating.\n";
        return 1;
    }
    cout << "Processing Input File.\n";
    initialize(countFemale, countMale, sumFemaleGPA, sumMaleGPA);
    sumGrades(inFile, countFemale, countMale, sumFemaleGPA, sumMaleGPA);
    avgFemale = averageGrade(sumFemaleGPA, countFemale);
    avgMale = averageGrade(sumMaleGPA, countMale);
    printResults(outFile, avgFemale, avgMale);
	
    closeFiles(inFile, outFile);
	return 0;
}

void openFiles(ifstream& input, ofstream& output)
{
    input.open("C:\\temp\\ex7.4data.txt");
    output.open("C:\\temp\\ex7.4.out");
    output << fixed << showpoint << setprecision(2);
}

void closeFiles(ifstream& input, ofstream& output)
{
    input.close();
    output.close();
}

void initialize(int& female, int& male, double& sumFemale, double& sumMale)
{
    female = 0;
    male = 0;
    sumFemale = 0.0;
    sumMale = 0.0;
}

void sumGrades(ifstream& input, int& female, int& male, double& sumFemale,
               double& sumMale)
{
    char gender;
    double GPA;

    input >> gender;
    while(input)
    {
        switch(gender)
        {
        case 'f': case 'F':
            female++;
            input >> GPA;
            sumFemale += GPA;
            break;
        case 'm': case 'M':
            male++;
            input >> GPA;
            sumMale += GPA;
            break;
        default:
            input.ignore(10, '\n');      //ignore line with other characters
        }
        input >> gender;
    }

}
    
double averageGrade(double sum, int number)
{
    if (number != 0)
        return sum / number;
    return 0.0;
}

void printResults(ofstream& output, double femaleAvg, double maleAvg)
{
    output << "The average GPA for females is: " << femaleAvg << endl;
    output << "The average GPA for males is:   " << maleAvg << endl;
}