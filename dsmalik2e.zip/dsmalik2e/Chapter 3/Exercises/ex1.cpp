#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream inFile;
    ofstream outFile;
    int test1, test2, test3, test4;
    char ch;

    inFile.open("C:\\temp\\inData.txt");
    outFile.open("C:\\temp\\outData.dat");

    cout << "Processing Data..." << endl;

    inFile >> test1 >> test2;
    outFile << "Sum of " << test1 << " and " << test2
            << " = " << test1 + test2 << "." << endl;

    inFile >> ch;
    outFile << "The character that comes after " << ch
            << " in the ASCII set is " << static_cast<char> (ch + 1)
            << "." << endl;
    inFile >> test3 >> test4;
    outFile << "The product of " << test3 << " and "
            << test4 << " = " << test3 * test4 << "." << endl;


    inFile.close();
    outFile.close();
    return 0;
}