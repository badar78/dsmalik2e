#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int main()
{
    double assessed, taxable, tax;
    ofstream outFile;

    outFile.open("C:\\temp\\outTax.txt");
        
    cout << "Enter assessed value of the property: " ;
    cin >> assessed;
    cout << "Processing Data..." << endl;
    taxable = assessed * 0.92;
    tax = taxable * 1.05 / 100.0;

    outFile << fixed << showpoint << setprecision(2);
    outFile << left << setw(30) << "Assessed value: " 
        << right << setw(12) << assessed << endl;
    outFile << left << setw(30) << "Taxable Amount: " 
        << right << setw(12) << taxable << endl;
    outFile << left << setw(30) << "Tax Rate for each $100.00: " 
        << right << setw(12) << 1.05 << endl;
    outFile << left << setw(30) << "Property Tax: " 
        << right << setw(12) << tax << endl;

    outFile.close();
    return 0;
}