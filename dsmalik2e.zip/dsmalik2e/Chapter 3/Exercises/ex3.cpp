#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

int main()
{
    ifstream inFile;
    int numberOfTickets, totalTickets = 0;
    double ticketPrice, totalSale = 0;
    
    inFile.open("ex3data.txt");
    
    cout << "Processing Data..." << endl;

    inFile >> ticketPrice >> numberOfTickets;
    totalTickets += numberOfTickets;
    totalSale += (ticketPrice * numberOfTickets);
    cout << ticketPrice << numberOfTickets << totalSale << endl;
    inFile >> ticketPrice >> numberOfTickets;
    totalTickets += numberOfTickets;
    totalSale += (ticketPrice * numberOfTickets);
    inFile >> ticketPrice >> numberOfTickets;
    totalTickets += numberOfTickets;
    totalSale += (ticketPrice * numberOfTickets);
    inFile >> ticketPrice >> numberOfTickets;
    totalTickets += numberOfTickets;
    totalSale += (ticketPrice * numberOfTickets);

    cout << fixed << showpoint << setprecision(2);
    cout << "A total of " << totalTickets << " sold with total sales: "
        << totalSale << endl;

    inFile.close();
    
    return 0;
}