#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    double number;
    
    cout << "Enter a decimal number: " ;
    cin >> number;
    
    cout << fixed << showpoint << setprecision(2);
    cout << "The number to 2 decimal places is " << number << endl;

    return 0;
}