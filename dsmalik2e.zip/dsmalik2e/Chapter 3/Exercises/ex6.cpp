#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
    ofstream outFile;
    string name;
    double grossAmount, netAmount, runTax;
    double totalTax = 0;

    cout << "Enter the name of Employee: ";
    getline(cin, name);
    cout << "Enter the gross amount: ";
    cin >> grossAmount;

    outFile.open("ex6Out.dat", ios::app);
    cout << "Processing Data..." << endl;

    outFile << name << endl;
    outFile << fixed << showpoint << setprecision(2);
    outFile << left << setfill('.') << setw(27) << "Gross Amount: "
        << " $" << setfill(' ')<< right << setw(7) << grossAmount << endl;

    //Fedral Tax
    runTax = grossAmount * 0.15;
    totalTax += runTax;
    outFile << left << setfill('.') << setw(27) << "Fedral Tax: "
        << " $" << setfill(' ')<< right << setw(7) << runTax << endl;
    //State Tax
    runTax = grossAmount * 0.035;
    totalTax += runTax;
    outFile << left << setfill('.') << setw(27) << "State Tax: "
        << " $" << setfill(' ')<< right << setw(7) << runTax << endl;
    //Social Security Tax
    runTax = grossAmount * 0.0575;
    totalTax += runTax;
    outFile << left << setfill('.') << setw(27) << "Social Security Tax: "
        << " $" << setfill(' ')<< right << setw(7) << runTax << endl;
    //Medicare/Medicaid Tax
    runTax = grossAmount * 0.0275;
    totalTax += runTax;
    outFile << left << setfill('.') << setw(27) << "Medicare/Medicaid Tax: "
        << " $" << setfill(' ')<< right << setw(7) << runTax << endl;
    //Pension Plan
    runTax = grossAmount * 0.05;
    totalTax += runTax;
    outFile << left << setfill('.') << setw(27) << "Pension Plan: "
        << " $" << setfill(' ')<< right << setw(7) << runTax << endl;
    //Health Insurance
    runTax = 75;
    totalTax += runTax;
    outFile << left << setfill('.') << setw(27) << "Health Insurance: "
        << " $" << setfill(' ')<< right << setw(7) << runTax << endl;
    //Net Pay
    netAmount = grossAmount - totalTax;
    outFile << left << setfill('.') << setw(27) << "Net Pay: "
        << " $" << setfill(' ')<< right << setw(7) << netAmount << endl;

    outFile << setfill('-') << setw(40) << " " << endl;

    outFile.close();
    return 0;
}