
#include <iostream>
#include "binarySearchTree.h"

using namespace std;

int main()
{

	bSearchTreeType<int>  treeRoot;
	
	int num;

	cout << "Enter numbers ending with -999." << endl;
	cin >> num;

	while (num != -999)
	{
		treeRoot.insert(num);
		cin >> num;
	}

	cout << endl << "Tree nodes in inorder: ";
	treeRoot.nonRecursiveInTraversal();

	cout << endl << "Tree nodes in preorder: ";
	treeRoot.nonRecursivePreTraversal();

	cout << endl << "Tree nodes in postorder: ";
	treeRoot.nonRecursivePostTraversal();
	cout << endl;

	return 0;
}