#include <iostream>
#include <string>

using namespace std;

bool isVowel(char ch);
string rotate(string pStr);
string pigLatinString(string pStr);
string pigLatinSentence(string pSentence);

int main()
{
    string str;

    cout << "This program converts a string text into pig Latin form."
        << "\nYou can include punctuation marks (.,?;:) at the end of the words."
        << "\nThere can be multiple spaces between words and words"
        << "\nconsisting of punctuation marks only."
        << "\nPlease enter a long sentence in the next line." << endl;
    getline(cin, str);

    cout << "The pig Latin form is as under: " << endl;
    cout << pigLatinSentence(str) << endl;

    return 0;
}


bool isVowel(char ch)
{
    switch (ch)
    {
    case 'A': case 'E': 
    case 'I': case 'O': 
    case 'U': case 'Y':
    case 'a': case 'e': 
    case 'i': case 'o': 
    case 'u': case 'y':
        return true;
    default:
        return false;
    }
}

string rotate(string pStr)
{
    string::size_type len = pStr.length();

    string rStr;

    rStr = pStr.substr(1, len - 1) + pStr[0];

    return rStr;
}

string pigLatinString(string pStr)
{
    string::size_type len;
    bool foundVowel;
    string append = "";
    char last;
    string::size_type counter;

    //Check last character(s) for punctuation mark and store them as append.
    len = pStr.length();
    if (len != 0)
    {
        last = pStr[len - 1];
        while (last == ',' || last == '.' || last == '?' || last == ';' || last == ':')
        {
            pStr = pStr.substr(0, len - 1);     //cut off last character
            append = last + append;             //concnate last character to append.
            len = pStr.length();
            if (len == 0)
                break;
            last = pStr[len - 1];
        }
    }

    if (pStr == "")             //in case of empty string remaining.
        pStr = append;
    else if (isVowel(pStr[0]))
        pStr = pStr + "-way" + append;	
    else
    {
        pStr = pStr + '-';
        pStr = rotate(pStr);

        len = pStr.length();
        foundVowel = false;

        for (counter = 1; counter < len - 1; counter++)
            if (isVowel(pStr[0]))
            {
                foundVowel = true;
                break;
            }
            else
                pStr = rotate(pStr);

        if (!foundVowel)
            pStr = pStr.substr(1, len-1) + "" + "-way" + append;
        else
            pStr = pStr + "ay" + append;
    }

        return pStr;
}

string pigLatinSentence(string pSentence)
{
    string rSentence = "";
    string singleWord;
    string::size_type totalLength, wordLength;
    string::size_type posSpace, posNextSpace;

    totalLength = pSentence.length();       //Needed to extract last word.
    posSpace = pSentence.find(' ',0);

    if (posSpace == string::npos)           //If there is no space,
        return pigLatinString(pSentence);   //then there is only one word
    
    //if there is at least one space.
    singleWord = pSentence.substr(0,posSpace);  //Extract first word.
    rSentence = pigLatinString(singleWord) + " ";
    posNextSpace = pSentence.find(' ',posSpace + 1);    //Find next space
    
    //Extract and manipulate middle words.
    while (posNextSpace != string::npos)
    {
        wordLength = posNextSpace - posSpace - 1;
        singleWord = pSentence.substr(posSpace + 1, wordLength);
        rSentence = rSentence + pigLatinString(singleWord) + " ";
        posSpace = posNextSpace;
        posNextSpace = pSentence.find(' ', posSpace + 1);
    }

    //Extract and manipulate last word.
    wordLength = totalLength - posSpace;
    singleWord = pSentence.substr(posSpace + 1, wordLength);
    rSentence = rSentence + pigLatinString(singleWord);

    return rSentence;
}