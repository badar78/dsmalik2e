#include <iostream>
using namespace std;

void pythagoreanTriple(int& aVal, int& bVal, int& cVal, int mVal, int nVal);

int main()
{   
    int m, n;
    int a, b, c;

    cout << "This program calcultes the Pythagorean triple if two integers are given."
        << "\nThe value of m should be greater than n."
        << "\nPlease enter the value of m(positive Integer): ";
    cin >> m;
    cout << "Please enter the value of n(positive Integer): ";
    cin >> n;
    
    while(m < 1 || n < 1 || m < n)
    {
        cout << "Input not meeting requirements. Enter again."
            << "\nPlease enter the value of m(positive Integer): ";
        cin >> m;
        cout << "Please enter the value of n(positive Integer): ";
        cin >> n;
    }
    
    pythagoreanTriple(a, b, c, m, n);

    cout << "The Pythagorean triple for give numbers is as under: " << endl
        << "a = " << a << " , b = " << b << " and c = " << c << endl;
    
    return 0;
}

void pythagoreanTriple(int& aVal, int& bVal, int& cVal, int mVal, int nVal)
{
    aVal = mVal * mVal - nVal * nVal;
    bVal = 2 * mVal * nVal;
    cVal = mVal * mVal + nVal * nVal;
}
