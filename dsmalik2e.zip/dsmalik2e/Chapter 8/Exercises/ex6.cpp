#include <iostream>
using namespace std;

void menu(char& op);
void addFractions(int& r, int& s, int a, int b, int c, int d);
void subtractFractions(int& r, int& s, int a, int b, int c, int d);
void multiplyFractions(int& r, int& s, int a, int b, int c, int d);
void divideFractions(int& r, int& s, int a, int b, int c, int d);

int main()
{   
    char opt;
    int numFirst, denFirst, numSecond, denSecond;
    int numResult, denResult;
    
    menu(opt);

    cout << "\nPlease enter the numerator of first numeber(Integer except zero): ";
    cin >> numFirst;
    while(numFirst == 0)
    {
        cout << "Invalid input. Enter again: ";
        cin >> numFirst;
    }
    cout << "Please enter the denominator of first numeber(Integer except zero): ";
    cin >> denFirst;
    while(denFirst == 0)
    {
        cout << "Invalid input. Enter again: ";
        cin >> denFirst;
    }
    cout << "\nPlease enter the numerator of second numeber(Integer except zero): ";
    cin >> numSecond;
    while(numSecond == 0)
    {
        cout << "Invalid input. Enter again: ";
        cin >> numSecond;
    }
    cout << "Please enter the denominator of first numeber(Integer except zero): ";
    cin >> denSecond;
    while(denSecond == 0)
    {
        cout << "Invalid input. Enter again: ";
        cin >> denSecond;
    }
    
    switch(opt)
    {
    case '+':
        addFractions(numResult, denResult, numFirst, denFirst, numSecond, denSecond);
        break;
    case '-':
        subtractFractions(numResult, denResult, numFirst, denFirst, numSecond, denSecond);
        break;
    case '*':
        multiplyFractions(numResult, denResult, numFirst, denFirst, numSecond, denSecond);
        break;
    case '/':
        divideFractions(numResult, denResult, numFirst, denFirst, numSecond, denSecond);
        break;
    default:
        cout << "Invalid operation.\n";
    }
    
    cout << "\nThe result is as under:" << endl << numFirst << " / " << denFirst
        << " " << opt << " " << numSecond << " / " << denSecond << " = "
        << numResult << " / " << denResult << endl;
    
    return 0;
}

void menu(char& op)
{
    cout << "This program does the arithmetic of two fractions."
        << "\nYou have to enter the numerators and denominator of both fractions"
        << "\n one by one, All numbers must be positive integers."
        << "\nSelect operation to be performed(+,-,*,/): ";
    cin >> op;
    while (!(op == '+' || op == '-' || op == '*' || op == '/'))
    {
        cout << "Invalid operatio. Enter again: ";
        cin >> op;
    }
}

void addFractions(int& r, int& s, int a, int b, int c, int d)
{
    r = a * d + b * c;
    s = b * d;
}

void subtractFractions(int& r, int& s, int a, int b, int c, int d)
{
    r = a * d + b * c;
    s = b * d;
}

void multiplyFractions(int& r, int& s, int a, int b, int c, int d)
{
    r = a * c;
    s = b * d;
}

void divideFractions(int& r, int& s, int a, int b, int c, int d)
{
    r = a * d;
    s = b * c;
}