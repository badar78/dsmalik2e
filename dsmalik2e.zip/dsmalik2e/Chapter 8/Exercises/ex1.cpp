#include <iostream>

using namespace std;

enum triangleType{scalene, isosceles, equilateral, noTriangle};

//function prototypes
triangleType triangleShape(double side1, double side2, double side3);
void displayType(triangleType type);

int main()
{
    double length1, length2, length3;
    triangleType shape;

    cout << "This program determines the shape of triangle based on its lengths." << endl;
    cout << "Please enter the three sides of the triangle: ";
    cin >> length1 >> length2 >> length3;

    shape = triangleShape(length1, length2, length3);
    displayType(shape);

    return 0;
}//end main

triangleType triangleShape(double side1, double side2, double side3)
{
    if (side1 + side2 <= side3 || side1 + side3 <= side2 || side2 + side3 <= side1)
        return noTriangle;
    else if (side1 == side2 && side2 == side3)
        return equilateral;
    else if (side1 == side2 || side1 == side3 || side2 == side3)
        return isosceles;
    else
        return scalene;
}

void displayType(triangleType type)
{
    switch(type)
    {
    case noTriangle:
        cout << "No triangle is formed by these sides." << endl;
        break;
    case equilateral:
        cout << "An equilateral triangle is formed by these sides." << endl;
        break;
    case isosceles:
        cout << "An isosceles triangle is formed by these sides." << endl;
        break;
    case scalene:
        cout << "A scalene triangle is formed by these sides." << endl;
        break;
    default:
        cout << "Invalid triangle type." << endl;
    }
}


