//Example string relational operations

#include <iostream>
#include <string>

using namespace std;

int main()
{
    string str1, str2, str3, str4;
    
    str1 = "Hello";
    str2 = "Hi";
    str3 = "Air";
    str4 = "Bill";
    
    cout << boolalpha;
    cout << str1 << " < " << str2 << " = " << (str1 < str2) << endl;
    cout << str1 << " > Hen = " << (str1 > "Hen") << endl;
    cout << str3 << " < An = " << (str3 < "An") << endl;	
    cout << str1 << " == hello = " << (str1 == "hello") << endl;
    cout << str4 << " >= Billy = " << (str4 >= "Billy") << endl;

    return 0;
}

