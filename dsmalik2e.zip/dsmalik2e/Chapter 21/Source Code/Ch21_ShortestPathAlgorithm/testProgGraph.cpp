
#include <iostream>
#include <fstream>
#include "weightedGraph.h"

using namespace std;

int main()
{
	cout << "See Programming Exercise 3." << endl;

	return 0;
}