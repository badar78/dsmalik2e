#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

const int noOfStudents = 20;

struct studentType
{
    string studentFName;
    string studentLName;
    int testScore;
    char grade;
};

void initialize(ifstream& infile, studentType list[], int listSize);
void calculateGrade(studentType list[], int listSize);
void printReport(ofstream& outfile, studentType list[], int listSize);
void highest(ofstream& outfile, studentType list[], int listSize);

int main()
{
    ifstream infile;     //input file stream variable
    ofstream outfile;    //output file stream variable
    string fileName;     //variable to hold the file name
    studentType studentsList[noOfStudents]; //array to hold the students' data

    cout << "Enter the input file name: ";
    cin >> fileName;
    infile.open(fileName.c_str());
    if (!infile)
    {
        cout << "Cannot open the input file." << endl;
        return 1;
    }

    initialize(infile, studentsList, noOfStudents);

    cout << "Enter the output file name: ";
    cin >> fileName;
    outfile.open(fileName.c_str());
    cout << "Processing input file. Output written to " << fileName << endl;
    calculateGrade(studentsList, noOfStudents);
    printReport(outfile, studentsList, noOfStudents);
    highest(outfile, studentsList, noOfStudents);
        
    infile.close();
    outfile.close();

    return 0;
}

void initialize(ifstream& infile, studentType list[], int listSize)
{
    for (int i = 0; i < listSize; i++)
        infile >> list[i].studentFName >> list[i].studentLName >> list[i].testScore;
}
void calculateGrade(studentType list[], int listSize)
{
    for (int i = 0; i < listSize; i++)
    {
       if (list[i].testScore >= 90)
            list[i].grade = 'A';
       else if (list[i].testScore >= 80)
            list[i].grade = 'B';
        else if (list[i].testScore >= 70)
            list[i].grade = 'C';
        else if (list[i].testScore >= 60)
            list[i].grade = 'D';
        else
            list[i].grade = 'F';
    }
}
            
void printReport(ofstream& outfile, studentType list[], int listSize)
{
    outfile << "Student Name        Grade" << endl
        << "______________________________" << endl << left;
    for (int i = 0; i < listSize; i++)
        outfile << setw(22) << list[i].studentLName + ", " + list[i].studentFName
            << list[i].grade << endl;
}
    
void highest(ofstream& outfile, studentType list[], int listSize) 
{
    int max = list[0].testScore;
    for (int i = 1; i < listSize; i++)
        if (list[i].testScore > max)
            max = list[i].testScore;
    outfile << "\n\nThe maximum test score is: " << max << endl;
    outfile << "Following student(s) attained the maximum score." << endl;
    for (int i = 0; i < listSize; i++)
        if (list[i].testScore == max)
            outfile << list[i].studentLName + ", " + list[i].studentFName << endl;
}
