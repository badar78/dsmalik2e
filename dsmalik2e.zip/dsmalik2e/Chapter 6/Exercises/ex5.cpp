#include <iostream>
#include <cmath>

using namespace std;
int reverseDigit(int num);

int main()
{
    int number;
    
    cout << "Enter an integer: ";
    cin >> number;

    cout << "The number with digits reversed is " << reverseDigit(number) << endl;
        
    return 0;
}

int reverseDigit(int num)
{
    bool isNegative = false;
    int pwr = 0, factor = 1,divider;
    int reverse = 0;

    if (num < 0)
    {
        num = -num;
        isNegative = true;
    }

    
    if (num < 10)
        reverse = num;
    else
    {
        while ( num / static_cast<int>(pow(10.0, pwr)) >= 10)
            pwr++;
        
        divider = static_cast<int>(pow(10.0, pwr));
        while (divider >= 1)
        {
            reverse += (num / divider)  * factor;
            num = num % divider;
            factor = factor * 10;
            divider /= 10;
         } //end while
     } //end else

    if (isNegative)
        return -reverse;
    return reverse;
}