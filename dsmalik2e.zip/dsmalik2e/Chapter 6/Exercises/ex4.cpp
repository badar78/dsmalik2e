#include <iostream>
using namespace std;

int one(int x, int y);
double two(int x, double a);

int main()
{
    int num1, num2, num3;
    double dec;

    cout << "Enter two integers: ";
    cin >> num1 >> num2;

    cout << "The function one returned with arguments " << num1 << " and "
        << num2 << ": " << one(num1, num2) << endl;

    cout << "\nEnter an integer: ";
    cin >> num3;
    cout << "Enter a number: ";
    cin >> dec;
    cout << "The function two returned with arguments " << num3 << " and "
        << dec << ": " << two(num3, dec) << endl;
    

    return 0;
}

int one(int x, int y)
{
    if (x > y)
        return x + y;
    return x - 2 * y;
}

double two(int x, double a)
{
    int first;
    double z;

    cout << "Enter a number: ";
    cin >> z;
    z = z + a;

    first = one(6, 8);
    first = first + x;

    if (z > 2 * first)
        return z;
    return 2 * first - z;
}