#include <iostream>
#include <cmath>

using namespace std;
bool isNumPalindrome(int num);

int main()
{
    int number;
    
    cout << "Enter an integer: ";
    cin >> number;

    if (isNumPalindrome(number))
        cout << "The number is Palindrome." << endl;
    else
        cout << "The number is not a Palindrome." << endl;
    
    return 0;
}

bool isNumPalindrome(int num)
{
    int pwr = 0;

    if (num < 10)
        return true;
    else
    {
        while ( num / static_cast<int>(pow(10.0, pwr)) >= 10)
            pwr++;

        while (num >= 10)
        {
            if ((num / static_cast<int>(pow(10.0, pwr))) != (num % 10))
                return false;
            else
            {
                num = num % static_cast<int>(pow(10.0, pwr));
                num = num / 10;
                pwr = pwr - 2;
            }
        } //end while
        return true;
    } //end else
}