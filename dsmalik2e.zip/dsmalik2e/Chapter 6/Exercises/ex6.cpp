#include <iostream>
#include <cmath>
using namespace std;

const double pi = 3.1416;
double distance(double x1, double y1, double x2, double y2);
double radius(double x1, double y1, double x2, double y2);
double circumference (double rad);
double area(double rad);

int main()
{
    double x1, y1, x2, y2;
    double rad;
    
    cout << "Enter x-coordinate of the center: ";
    cin >> x1;
    cout << "Enter y-coordinate of the center: ";
    cin >> y1;
    cout << "Enter x-coordinate of the point: ";
    cin >> x2;
    cout << "Enter y-coordinate of the center: ";
    cin >> y2;
    
    rad = radius(x1, y1, x2, y2);
    cout << "\nThe radius of the circle is: " << rad << endl;
    cout << "The diameter of the circle is: " << 2 * rad << endl;
    cout << "The circumference of the circle is: " << circumference(rad) << endl;
    cout << "The area of the circle is: " << area(rad) << endl;

    return 0;
}

double distance(double x1, double y1, double x2, double y2)
{
    return pow(pow(x2 - x1,2) + pow(y2 - y1,2),0.5);
}

double radius(double x1, double y1, double x2, double y2)
{
    return distance(x1, y1, x2, y2);
}

double circumference (double rad)
{
    return 2 * pi * rad;
}

double area(double rad)
{
    return pi * rad * rad;
}
