#include <iostream>

using namespace std;

bool isVowel(char ch);

int main()
{
    char chr;
    int no = 0;

    cout << "Enter sequence of characters: ";
    cin.get(chr);

    while (chr != '\n')
    {
        if (isVowel(chr))
            no++;
        cin.get(chr);
    }
    
    cout << "The number of vowels is: " << no << endl;
    return 0;
}

bool isVowel(char ch)
{
    if (ch == 'a' || ch == 'A')
        return true;
    else if (ch == 'e' || ch == 'E')
        return true;
    else if (ch == 'i' || ch == 'I')
        return true;
    else if (ch == 'o' || ch == 'O')
        return true;
    else if (ch == 'u' || ch == 'U')
        return true;
    else
        return false;
}