#include <iostream>
using namespace std;

int main()
{   
    char string[51];
    int i;
    
    cout << "Please enter a string of maximum 50 characters on next line.\n";
    cin.get(string, 51);
    
    for (i = 0; string[i] != '\0'; i++)
        string[i] = toupper(string[i]);
    
    /*Alternate solution.
    int factor;
    factor = 'a' - 'A';
    for (i = 0; string[i] != '\0'; i++)
        if (string[i] >= 'a' && string[i] <= 'z')
            string[i] -= factor;
    */

    cout << "The string with uppercase letters is.\n";
    cout << string << endl;
        
   	return 0;
}
