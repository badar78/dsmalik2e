#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
   	double alpha[50];
    int i;
    
    //initialization.
    for (i = 0; i < 25; i++)
        alpha[i] = i * i;
    for (i = 25; i < 50; i++)
        alpha[i] = 3 * i;
	
    //printing
    cout << "The array initialized is as follows." << endl << endl;
    for (i = 0; i < 50; i++)
    {
        cout << setw(4) << alpha[i];
        if ( (i + 1) % 10 == 0)
            cout << endl;
    }
	cout << endl;

	return 0;
}
