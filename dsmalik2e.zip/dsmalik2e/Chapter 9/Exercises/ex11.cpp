#include <iostream>
#include <iomanip>
using namespace std;

const int arraySize = 101;

int main()
{   
    int counter[arraySize] = {0};
    int number;
    
    cout << "Please enter a sequence of numbers beteen 0 and 100 on next line."
        << "Enter -999 to end" << endl;
    cin >> number;
    
    while (number != -999)
    {
        counter[number]++;
        cin >> number;
    }

    //printing the output.
    cout << "Number     Count" << endl << left;
    for (int i = 0; i < arraySize; i++)
        if (counter[i] != 0)
            cout << setw(11) << i << setw(5) << counter[i] << endl;
                
   	return 0;
}
