#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

const int candidates = 5;

int main()
{   
    string names[candidates];
    int votes[candidates];
    int total = 0;
    int index, maxIndex = 0;
    double percents[candidates];

    cout << "This program allows you to enter the last name and votes of "
        << candidates << " candidates and outputs the winning candidate.\n";

    for (index = 0; index < candidates; index++)
    {
        cout << "Enter the last name of candidates followed by votes: ";
        cin >> names[index] >> votes[index];
        total += votes[index];
    }
   
    cout << endl << fixed << showpoint << setprecision(2);
    cout << "Candidate     Votes Received     % of Total Votes" << endl;

    for (index = 0; index < candidates; index++)
    {
        percents[index] = (static_cast<double>(votes[index])/total) * 100.00;
        if (votes[index] > votes[maxIndex])
            maxIndex = index;
        cout << left << setw(20) << names[index] << setw(18) << votes[index] << right 
            << setw(5) << percents[index] << endl;
    }
    
   cout << left << setw(20) << "Total" << setw(18) << total << endl;
   cout << "The winner of the Election is " << names[maxIndex] << ".\n";
        
   	return 0;
}
