#include <iostream>
#include <iomanip>
using namespace std;

const int months = 12;
const int cats = 2;
void getData(double data[][12]);
double average(double datarow[], int arraySize);
int indexHigh(double datarow[], int arraySize);
int indexLow(double datarow[], int arraySize);

int main()
{   
    double temperatures[cats][months];
    double avgHigh, avgLow;
    double lowest, highest;
    int indexLowest, indexHighest;

    getData(temperatures);
    avgLow = average(temperatures[0], months);
    avgHigh = average(temperatures[1], months);
    indexLowest = indexLow(temperatures[0], months);
    lowest = temperatures[0][indexLowest];
    indexHighest = indexHigh(temperatures[1], months);
    highest = temperatures[1][indexHighest];

    cout << fixed << showpoint << setprecision(2);
    cout << "\nThe average high temperature of the year: " << avgHigh << endl;
    cout << "The average low temperature of the year: " << avgLow << endl;
    cout << "The lowest temperature was in month " << (indexLowest + 1)
        << " that was: " << lowest << endl;
    cout << "The highest temperature was in month " << (indexHighest + 1)
        << " that was: " << highest << endl;    
            
   	return 0;
}

void getData(double data[5][months])
{
    cout << "Please enter the temperature data month wise.\n";

    for (int i = 0; i < months; i++)
    {
        cout << "Enter lowest temperature followed by highest for month " 
            << (i + 1) << ": ";
        cin >> data[0][i] >> data[1][i];
    }
}

double average(double datarow[], int arraySize)
{
    double sum = 0.0;
    
    for(int i = 0; i < arraySize; i++)
        sum += datarow[i];
    return sum / arraySize;
}

int indexHigh(double datarow[], int arraySize)
{
    int maxIndex = 0;
    for (int i = 1; i < arraySize; i++)
        if (datarow[i] > datarow[maxIndex])
            maxIndex = i;
    return maxIndex;
}

int indexLow(double datarow[], int arraySize)
{
    int minIndex = 0;
    for (int i = 1; i < arraySize; i++)
        if (datarow[i] < datarow[minIndex])
            minIndex = i;
    return minIndex;
}