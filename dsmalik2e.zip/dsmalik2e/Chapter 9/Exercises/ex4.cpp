#include <iostream>
#include <iomanip>
using namespace std;

const int arraySize = 8;

int main()
{   
    double scores[arraySize] = {0};   //Initialize counter array to zero
    double points, minScore, maxScore;
    int i;
    
    cout << "Please enter the " << arraySize << " judge's scores: ";
    for (i = 0; i < arraySize; i++)
        cin >> scores[i];

    minScore = maxScore = points = scores[0];
    for(i = 1; i < arraySize; i++)
    {
        points += scores[i];
        if (scores[i] > maxScore)
            maxScore = scores[i];
        if (scores[i] < minScore)
            minScore = scores[i];
    }
    points = points - maxScore - minScore;

    cout << fixed << showpoint << setprecision(2);
    cout << "The points obtained by the gymnastics are: " << points << endl;
        
   	return 0;
}
