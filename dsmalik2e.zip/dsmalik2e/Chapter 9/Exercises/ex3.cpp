#include <iostream>
#include <fstream>
using namespace std;

int main()
{   
    int counter[8] = {0};   //Initialize counter array to zero
    int score, scale;
    ifstream inFile;
    ofstream outFile;

    inFile.open("C:\\temp\\ex9.3data.txt");
    if (!inFile)
    {
        cout << "No input file found. Program terminating.\n";
        return 1;
    }
    outFile.open("C:\\temp\\ex9.3out.txt");
    cout << "Processing input file.\n\n";

    inFile >> score;
    while (inFile)
    {
        scale = score / 25;
        if (scale == 8)     //to catch score 200
            counter[7]++;
        else
            counter[scale]++;
        inFile >> score;
    }

    //outputting result
    for (int i = 0; i < 7; i++)
    {
        outFile << "The number of students between " << i * 25 << "-" << i * 25 + 24
        << " is: " << counter[i] << endl;
        cout << "The number of students between " << i * 25 << "-" << i * 25 + 24
        << " is: " << counter[i] << endl;
    }
    outFile << "The number of students between 175-200 is: " << counter[7] << endl;
    cout << "The number of students between 175-200 is: " << counter[7] << endl;
    cout << "\nThe output saved in C:\\temp\\ex9.3out.txt\n";
    
    inFile.close();
    outFile.close();

	return 0;
}
