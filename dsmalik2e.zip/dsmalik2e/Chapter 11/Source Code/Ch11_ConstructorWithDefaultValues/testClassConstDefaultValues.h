//Constructor with default Parameters

class testClass
{
public:
	void print() const;			

	testClass(int = 0, int = 0, double = 0.0, char = '*');

private:
	int x;
	int y;
	double z;
	char ch;
};

