
class classIllusFriend
{
	friend void two(classIllusFriend cIFObject);

public:
	void print();
	void setx(int a);
private:
	int x;
};


