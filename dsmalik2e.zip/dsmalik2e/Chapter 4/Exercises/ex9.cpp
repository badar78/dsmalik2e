#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    double number1, number2;
    char operation;

    cout << "Enter first operand: ";
    cin >> number1;
    cout << "Enter second operand: ";
    cin >> number2;
    cout << "Enter the operation (+,-,/,*): ";
    cin >> operation;
    //cout << fixed << setprecision(2);

    switch(operation)
    {
        case '+':
            cout << number1 << " + " << number2
                << " = " << number1 + number2 << endl;
            break;
        case '-':
            cout << number1 << " - " << number2
                << " = " << number1 - number2 << endl;
            break;
        case '*':
            cout << number1 << " * " << number2
                << " = " << number1 * number2 << endl;
            break;
        case '/':
            if (number2 == 0)
                cout << "Divison by zero not allowed." << endl;
            else
                cout << number1 << " / " << number2
                   << " = " << number1 / number2 << endl;
            break;
        default:
            cout << "Invalid operation." << endl;
    }

    return 0;
}
