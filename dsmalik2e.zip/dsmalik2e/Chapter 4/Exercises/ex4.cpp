#include <iostream>
#include <iomanip>

using namespace std;

const double connectionFee = 1.99;
const double firstThree = 2.00;
const double costPerMin = 0.45;

int main()
{
    int callTime;
    double amount;

    cout << "Enter the total call time in minutes (integer): ";
    cin >> callTime;

    if (callTime <= 3)
        amount = connectionFee + firstThree;
    else
        amount = connectionFee + firstThree + (callTime - 3) * costPerMin;

    cout << fixed << showpoint << setprecision(2);
    cout << "The amount due is $" << amount << endl;

    return 0;
}
