#include <iostream>

using namespace std;

int main()
{
    int num, factor;

    cout << "Enter an integer between 0 and 35: ";
    cin >> num;

    factor = static_cast<int>('A') - 10;

    if (num >= 0 && num < 10)
        cout << "It represents " << num << endl;
    else if (num >= 10 && num <= 35)
        cout << "It represents " << static_cast<char>(num + factor) << endl;
    else
        cout << "Invalid number" << endl;

    return 0;
}
