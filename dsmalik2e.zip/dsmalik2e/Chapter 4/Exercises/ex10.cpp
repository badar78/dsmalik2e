#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int acctNo;
    char acctType;
    double minBal, currBal, netBal;

    cout << "Enter account number, type, minimum balance and current balance: ";
    cin >> acctNo >> acctType >> minBal >> currBal;
    cout << fixed << showpoint << setprecision(2);

    cout << "Account Number: " << acctNo << endl;

    switch (acctType)
    {
    case 'S':
    case 's':
        cout << "Account Type:   Saving" << endl;
        if (currBal < minBal)
        {
            cout << "Account is less than the minimum balance." << endl;
            netBal = currBal - 15.00;
        }
        else
        {
            cout << "Adding 4% interest" << endl;
            netBal = currBal * 1.04;
        }
        break;

    case 'C':
    case 'c':
        cout << "Account Type:   Checking" << endl;
        if (currBal < minBal)
        {
            cout << "Account is less than the minimum balance." << endl;
            netBal = currBal - 25.00;
        }
        else if ((currBal - minBal) <= 5000)
        {
            cout << "Adding 3% interest" << endl;
            netBal = currBal * 1.03;
        }
        else
        {
            cout << "Adding 5% interest" << endl;
            netBal = currBal * 1.05;
        }
        break;

    default:
        cout << "Invalid account type" << endl;
    }

    cout << "Net Balance:    " << netBal << endl;

    return 0;
}