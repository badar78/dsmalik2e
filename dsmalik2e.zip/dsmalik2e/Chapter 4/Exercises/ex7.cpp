#include <iostream>

using namespace std;

int main()
{
    double x, y;
    
    cout << "Enter x-coordinate: ";
    cin >> x;
    cout << "Enter y-coordinate: ";
    cin >> y;
    
    if (x == 0 && y == 0)
        cout << "(" << x << "," << y << ") is the origin." << endl;
    else if (y == 0)
        cout << "(" << x << "," << y << ") is on the x-axis." << endl;
    else if (x == 0)
        cout << "(" << x << "," << y << ") is on the y-axis." << endl;
    else if (x > 0 && y > 0)
        cout << "(" << x << "," << y << ") is in the first quadrant." << endl;
    else if (x < 0 && y > 0)
        cout << "(" << x << "," << y << ") is in the second quadrant." << endl;
    else if (x < 0 && y < 0)
        cout << "(" << x << "," << y << ") is in the third quadrant." << endl;
    else 
        cout << "(" << x << "," << y << ") is in the fourth quadrant." << endl;
    return 0;
}
